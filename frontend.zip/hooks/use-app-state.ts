"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import {
  goals as initialGoals,
  type Goal,
  type Simulation,
  type AutomationAction,
  type ResultCard,
  bills as initialBills,
  type Bill,
} from "@/lib/data"
import { useToast } from "@/hooks/use-toast"

export type Screen =
  | "login"
  | "dashboard"
  | "spend-tracking"
  | "simulations"
  | "simulation-setup"
  | "simulating"
  | "simulation-results"
  | "ai-actions"
  | "action-detail"
  | "profile"
  | "connect-account"
  | "credit-score"
  | "net-worth-detail"

export type Demographic = "genz" | "millennial"

export interface SpendingCategory {
  id: string
  name: string
  icon: string
  spent: number
  budget: number
  color: string
}

export interface AIAction {
  id: string
  title: string
  description: string
  rationale: string
  type: "optimization" | "simulation"
  simulationTag?: string
  potentialSaving: number
  steps: string[]
  status?: "suggested" | "completed"
}

export interface Account {
  id: number
  name: string
  institution: string
  balance: number
  icon: string
  type: "asset" | "liability"
}

export interface SimulationParameter {
  id: string
  name: string
  value: number
  min: number
  max: number
  unit: string
  description: string
}

export interface SimulationInsight {
  id: string
  title: string
  description: string
  rationale: string
  actionRequired: string
  impact: "high" | "medium" | "low"
}

export interface SelectedSimulation {
  id: string
  title: string
  subtitle: string
  icon: React.ReactNode
  color: string
  borderColor: string
}

export interface AppState {
  currentScreen: Screen
  setCurrentScreen: (screen: Screen) => void
  selectedSimulations: Simulation[]
  toggleSimulation: (sim: Simulation) => void
  runSimulations: () => void
  isSimulating: boolean
  simulationProgress: number
  activeAutomations: AutomationAction[]
  saveAutomation: (automation: AutomationAction) => void
  removeAutomation: (automationTitle: string) => void
  setSelectedSimulations: (sims: Simulation[]) => void
  goals: Goal[]
  addGoal: (goal: Omit<Goal, "id">) => void
  selectedGoal: Goal | null
  setSelectedGoal: (goal: Goal | null) => void
  isThoughtDetailOpen: boolean
  setThoughtDetailOpen: (isOpen: boolean) => void
  selectedThought: ResultCard | null
  setSelectedThought: (thought: ResultCard | null) => void
  isChatOpen: boolean
  setChatOpen: (isOpen: boolean) => void
  bills: Bill[]
  payBill: (billId: number) => void
  accounts: Account[]
  isGoalFeedbackOpen: boolean
  setGoalFeedbackOpen: (isOpen: boolean) => void
  monthlyIncome: number
  monthlySpending: { total: number; topCategory: { name: string; amount: number } }
  selectedAction: AIAction | null
  setSelectedAction: (action: AIAction | null) => void
  spendingCategories: SpendingCategory[]
  recurringExpenses: {
    total: number
    items: { name: string; amount: number; icon: string; moreCount?: number }[]
  }
  aiActions: AIAction[]
  demographic: Demographic
  setDemographic: (demo: Demographic) => void
  // New simplified simulation state
  currentSimulation: SelectedSimulation | null
  setCurrentSimulation: (sim: SelectedSimulation | null) => void
  isAIChatOpen: boolean
  setAIChatOpen: (isOpen: boolean) => void
  selectedActionForChat: AIAction | null
  setSelectedActionForChat: (action: AIAction | null) => void
}

const demographicData = {
  genz: {
    accounts: [
      {
        id: 1,
        name: "Chase College Checking",
        institution: "Chase",
        balance: 2847,
        icon: "/logos/chase.png",
        type: "asset",
      },
      { id: 2, name: "Savings Account", institution: "Chase", balance: 5200, icon: "/logos/chase.png", type: "asset" },
      { id: 3, name: "Student Loan", institution: "Federal", balance: -28500, icon: "🎓", type: "liability" },
      {
        id: 4,
        name: "Credit Card",
        institution: "Discover",
        balance: -1200,
        icon: "/logos/amex.png",
        type: "liability",
      },
    ],
    creditScore: 650,
    monthlyIncome: 3200,
    monthlySpending: { total: 2100, topCategory: { name: "Food & Dining", amount: 450 } },
    spendingCategories: [
      { id: "food", name: "Food & Dining", icon: "🍕", spent: 450, budget: 400, color: "red" },
      { id: "transport", name: "Transportation", icon: "🚗", spent: 180, budget: 200, color: "green" },
      { id: "entertainment", name: "Entertainment", icon: "🎬", spent: 220, budget: 250, color: "green" },
      { id: "shopping", name: "Shopping", icon: "🛍️", spent: 320, budget: 300, color: "red" },
    ],
  },
  millennial: {
    accounts: [
      { id: 1, name: "Chase Checking", institution: "Chase", balance: 8500, icon: "/logos/chase.png", type: "asset" },
      {
        id: 2,
        name: "Fidelity 401k",
        institution: "Fidelity",
        balance: 45000,
        icon: "/logos/fidelity.png",
        type: "asset",
      },
      {
        id: 3,
        name: "High-Yield Savings",
        institution: "Marcus",
        balance: 15000,
        icon: "/logos/chase.png",
        type: "asset",
      },
      {
        id: 4,
        name: "Investment Account",
        institution: "Vanguard",
        balance: 22000,
        icon: "/logos/vanguard.png",
        type: "asset",
      },
      {
        id: 6,
        name: "Apple Card",
        institution: "Goldman Sachs",
        balance: -2234,
        icon: "/logos/amex.png",
        type: "liability",
      },
      {
        id: 7,
        name: "Chase Freedom",
        institution: "Chase",
        balance: -1800,
        icon: "/logos/chase.png",
        type: "liability",
      },
      {
        id: 8,
        name: "Student Loan",
        institution: "Federal",
        balance: -12000,
        icon: "🎓",
        type: "liability",
      },
    ],
    creditScore: 780,
    monthlyIncome: 8500,
    monthlySpending: { total: 4200, topCategory: { name: "Housing", amount: 2200 } },
    spendingCategories: [
      { id: "housing", name: "Housing", icon: "🏠", spent: 2200, budget: 2500, color: "green" },
      { id: "groceries", name: "Groceries", icon: "🥬", spent: 650, budget: 700, color: "green" },
      { id: "transport", name: "Transportation", icon: "🚗", spent: 450, budget: 500, color: "green" },
      { id: "entertainment", name: "Entertainment", icon: "🎬", spent: 380, budget: 400, color: "green" },
    ],
  },
}

export default function useAppState(): AppState {
  const { toast } = useToast()
  const [currentScreen, setCurrentScreen] = useState<Screen>("login")
  const [selectedSimulations, setSelectedSimulations] = useState<Simulation[]>([])
  const [isSimulating, setIsSimulating] = useState(false)
  const [simulationProgress, setSimulationProgress] = useState(0)
  const [activeAutomations, setActiveAutomations] = useState<AutomationAction[]>([])
  const [goals, setGoals] = useState<Goal[]>(initialGoals)
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null)
  const [isThoughtDetailOpen, setThoughtDetailOpen] = useState(false)
  const [selectedThought, setSelectedThought] = useState<ResultCard | null>(null)
  const [isChatOpen, setChatOpen] = useState(false)
  const [bills, setBills] = useState<Bill[]>(initialBills)
  const [isGoalFeedbackOpen, setGoalFeedbackOpen] = useState(false)
  const [selectedAction, setSelectedAction] = useState<AIAction | null>(null)
  const [demographic, setDemographic] = useState<Demographic>("millennial")

  // New simplified simulation state
  const [currentSimulation, setCurrentSimulation] = useState<SelectedSimulation | null>(null)

  // AI Chat state
  const [isAIChatOpen, setAIChatOpen] = useState(false)
  const [selectedActionForChat, setSelectedActionForChat] = useState<AIAction | null>(null)

  // Get current demographic data
  const currentData = demographicData[demographic]
  const [accounts, setAccounts] = useState<Account[]>(currentData.accounts)
  const [monthlyIncome] = useState(currentData.monthlyIncome)
  const [monthlySpending] = useState(currentData.monthlySpending)
  const [spendingCategories] = useState<SpendingCategory[]>(currentData.spendingCategories)

  const [recurringExpenses] = useState({
    total: demographic === "genz" ? 850 : 1352,
    items:
      demographic === "genz"
        ? [
            { name: "Rent", amount: 600, icon: "🏠" },
            { name: "Phone", amount: 45, icon: "📱" },
            { name: "Streaming", amount: 25, icon: "📺" },
            { moreCount: 3 },
          ]
        : [
            { name: "Mortgage", amount: 1200, icon: "🏠" },
            { name: "Internet", amount: 79, icon: "📶" },
            { name: "Phone", amount: 45, icon: "📱" },
            { moreCount: 2 },
          ],
  })

  const [aiActions] = useState<AIAction[]>([
    {
      id: "high-yield-savings",
      title: demographic === "genz" ? "Open High-Yield Savings" : "Move to High-Yield Savings",
      description:
        demographic === "genz"
          ? "Start earning 4.5% APY on your savings"
          : "Detected excess in checking, earning you +$8/month",
      rationale:
        demographic === "genz"
          ? "Analysis of your account shows $5,200 in savings earning minimal interest (likely 0.01% APY). By moving to a high-yield savings account with 4.5% APY, you'd earn an additional $234 annually. This is a risk-free way to optimize your money while maintaining liquidity for emergencies."
          : "Our analysis detected $3,200 sitting in your checking account earning 0.01% APY. This excess cash (beyond your typical monthly expenses) could be moved to a high-yield savings account earning 4.5% APY, generating an additional $144 annually with zero risk and full liquidity.",
      type: "optimization",
      potentialSaving: demographic === "genz" ? 15 : 8,
      steps: [
        "Research high-yield savings accounts",
        "Open account with partner bank",
        "Set up automatic transfer",
        "Monitor and adjust monthly",
      ],
      status: "suggested",
    },
    {
      id: "budget-optimization",
      title: demographic === "genz" ? "Create First Budget" : "Optimize Monthly Budget",
      description:
        demographic === "genz" ? "Track spending and save $200/month" : "Reduce unnecessary expenses by $150/month",
      rationale:
        demographic === "genz"
          ? "Transaction analysis reveals you're spending $450/month on food & dining (21% of income) and $220 on entertainment (10% of income). Compared to peers in your income bracket, this is 35% higher than average. A structured budget with meal planning and entertainment limits could reduce spending by $200/month while maintaining your lifestyle quality."
          : "Our spending analysis identified $380/month on entertainment and multiple subscription services totaling $89/month. By optimizing subscriptions (canceling unused services) and reducing dining out by 2 meals per week, you could save $150/month without significantly impacting your lifestyle. This represents a 3.6% reduction in total spending.",
      type: "optimization",
      potentialSaving: demographic === "genz" ? 200 : 150,
      steps: ["Analyze spending patterns", "Set category budgets", "Set up spending alerts", "Review monthly progress"],
      status: "suggested",
    },
    {
      id: "subscription-audit",
      title: "Cancel Unused Subscriptions",
      description: "Found 3 unused subscriptions costing $47/month",
      rationale:
        "Analysis of your recurring charges identified subscriptions you haven't used in the past 60 days. These include a gym membership ($29/month), streaming service ($12/month), and software subscription ($6/month) that show no recent activity.",
      type: "optimization",
      potentialSaving: 47,
      steps: ["Review subscription list", "Cancel unused services", "Set up usage tracking", "Monthly review process"],
      status: "suggested",
    },
    {
      id: "cashback-optimization",
      title: "Optimize Credit Card Rewards",
      description: "Switch to better cashback card for +$23/month",
      rationale:
        "Your current spending patterns show 40% on groceries and gas. A cashback card with 3% on these categories vs your current 1% would generate an additional $276 annually based on your spending history.",
      type: "optimization",
      potentialSaving: 23,
      steps: ["Compare cashback cards", "Apply for optimal card", "Update payment methods", "Track rewards earned"],
      status: "suggested",
    },
    {
      id: "emergency-fund-completed",
      title: "Emergency Fund Optimization",
      description: "Successfully moved $5,000 to high-yield savings",
      rationale:
        "Completed action that moved emergency fund to Marcus savings account earning 4.5% APY instead of 0.01%.",
      type: "optimization",
      potentialSaving: 18,
      steps: ["Account opened", "Funds transferred", "Auto-transfer setup", "Monthly monitoring active"],
      status: "completed",
    },
    {
      id: "bill-negotiation-completed",
      title: "Negotiated Internet Bill",
      description: "Reduced monthly internet cost by $15/month",
      rationale:
        "Successfully negotiated with internet provider to reduce monthly bill from $79 to $64 by switching to a promotional rate.",
      type: "optimization",
      potentialSaving: 15,
      steps: ["Called provider", "Negotiated rate", "Confirmed new billing", "Set calendar reminder"],
      status: "completed",
    },
  ])

  // Update accounts when demographic changes
  useEffect(() => {
    const newData = demographicData[demographic]
    setAccounts(newData.accounts)
  }, [demographic])

  const toggleSimulation = (sim: Simulation) => {
    if (selectedSimulations.find((s) => s.id === sim.id)) {
      setSelectedSimulations(selectedSimulations.filter((s) => s.id !== sim.id))
    } else if (selectedSimulations.length < 3) {
      setSelectedSimulations([...selectedSimulations, sim])
    }
  }

  const runSimulations = () => {
    setIsSimulating(true)
    setCurrentScreen("simulating")
  }

  const removeAutomation = useCallback((automationTitle: string) => {
    setActiveAutomations((prev) => prev.filter((a) => a.title !== automationTitle))
  }, [])

  const saveAutomation = (automation: AutomationAction) => {
    if (!activeAutomations.find((a) => a.title === automation.title)) {
      setActiveAutomations((prev) => [...prev, automation])
      toast({
        title: "Automation Activated",
        description: `${automation.title} is now running.`,
        action: (
          <button
            onClick={() => removeAutomation(automation.title)}
            className="rounded-md px-3 py-1 text-sm font-medium text-white ring-1 ring-white/50 hover:bg-white/10"
          >
            Undo
          </button>
        ),
      })
    }
  }

  const addGoal = (goal: Omit<Goal, "id">) => {
    const newGoal = { ...goal, id: Date.now() }
    setGoals((prev) => [...prev, newGoal])
    setCurrentScreen("goals")
  }

  const payBill = (billId: number) => {
    const bill = bills.find((b) => b.id === billId)
    if (!bill || bill.status === "paid") return

    setAccounts((prevAccounts) =>
      prevAccounts.map((acc) => {
        if (acc.name === "Chase Checking") {
          return { ...acc, balance: acc.balance - bill.amount }
        }
        return acc
      }),
    )

    setBills((prevBills) =>
      prevBills.map((b) => {
        if (b.id === billId) {
          return { ...b, status: "paid" }
        }
        return b
      }),
    )

    toast({
      title: "Bill Paid",
      description: `${bill.name} for $${bill.amount.toFixed(2)} has been paid.`,
    })
  }

  useEffect(() => {
    if (isSimulating) {
      const interval = setInterval(() => {
        setSimulationProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            setTimeout(() => {
              setCurrentScreen("simulation-results")
              setIsSimulating(false)
              setSimulationProgress(0)
            }, 500)
            return 100
          }
          return prev + 10
        })
      }, 300)
      return () => clearInterval(interval)
    }
  }, [isSimulating])

  return {
    currentScreen,
    setCurrentScreen,
    selectedSimulations,
    toggleSimulation,
    runSimulations,
    isSimulating,
    simulationProgress,
    activeAutomations,
    saveAutomation,
    removeAutomation,
    setSelectedSimulations,
    goals,
    addGoal,
    selectedGoal,
    setSelectedGoal,
    isThoughtDetailOpen,
    setThoughtDetailOpen,
    selectedThought,
    setSelectedThought,
    isChatOpen,
    setChatOpen,
    bills,
    payBill,
    accounts,
    isGoalFeedbackOpen,
    setGoalFeedbackOpen,
    monthlyIncome,
    monthlySpending,
    selectedAction,
    setSelectedAction,
    spendingCategories,
    recurringExpenses,
    aiActions,
    demographic,
    setDemographic,
    currentSimulation,
    setCurrentSimulation,
    isAIChatOpen,
    setAIChatOpen,
    selectedActionForChat,
    setSelectedActionForChat,
  }
}
