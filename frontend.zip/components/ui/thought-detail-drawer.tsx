"use client"

import type { AppState } from "@/hooks/use-app-state"
import { motion, AnimatePresence } from "framer-motion"
import { X } from "lucide-react"

export default function ThoughtDetailDrawer({ isThoughtDetailOpen, setThoughtDetailOpen, selectedThought }: AppState) {
  return (
    <AnimatePresence>
      {isThoughtDetailOpen && selectedThought && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setThoughtDetailOpen(false)}
            className="fixed inset-0 z-30 bg-black/50 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-0 left-0 right-0 z-40 max-h-[80vh] rounded-t-3xl bg-gray-900 text-white"
          >
            <div className="relative p-6">
              <div className="absolute top-3 left-1/2 h-1.5 w-12 -translate-x-1/2 rounded-full bg-gray-700" />
              <button
                onClick={() => setThoughtDetailOpen(false)}
                className="absolute top-4 right-4 rounded-full p-1 text-gray-400 hover:bg-gray-700"
                aria-label="Close"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="mt-6 flex items-center gap-4">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-white/10 text-2xl">
                  {selectedThought.emoji}
                </div>
                <div>
                  <h2 className="text-xl font-bold">{selectedThought.title || `Thought ${selectedThought.id}`}</h2>
                  <p className="text-sm text-gray-400">AI Analysis</p>
                </div>
              </div>
            </div>
            <div className="h-[1px] bg-white/10" />
            <div className="max-h-[calc(80vh-120px)] overflow-y-auto p-6">
              <p className="whitespace-pre-line text-lg leading-relaxed text-gray-300">
                {selectedThought.detailedExplanation}
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
