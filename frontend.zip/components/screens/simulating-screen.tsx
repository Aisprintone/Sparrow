"use client"

import type { AppState } from "@/hooks/use-app-state"
import { RefreshCw } from "lucide-react"
import { motion } from "framer-motion"
import { Progress } from "@/components/ui/progress"

export default function SimulatingScreen({ selectedSimulations, simulationProgress }: AppState) {
  return (
    <div className="flex h-full flex-col items-center justify-center p-6 text-white">
      {/* 3D Animation Container */}
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="relative mb-8 h-48 w-48"
      >
        <motion.div
          className="absolute inset-0 rounded-full bg-white/20"
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        ></motion.div>
        <motion.div
          className="absolute inset-4 rounded-full bg-white/30"
          animate={{ scale: [1, 0.9, 1], opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.5 }}
        ></motion.div>
        <div className="absolute inset-8 flex items-center justify-center rounded-full bg-white/40 backdrop-blur-sm">
          <RefreshCw className="h-12 w-12 animate-spin text-white" style={{ animationDuration: "3s" }} />
        </div>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0, transition: { delay: 0.2 } }}
        className="mb-2 text-2xl font-bold"
      >
        Running Simulations
      </motion.h2>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0, transition: { delay: 0.3 } }}
        className="mb-8 text-center text-white/80"
      >
        Analyzing {selectedSimulations.length} scenarios across 10,000 iterations
      </motion.p>

      {/* Progress Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0, transition: { delay: 0.4 } }}
        className="w-full max-w-xs"
      >
        <Progress
          value={simulationProgress}
          className="h-2 bg-white/20 backdrop-blur-sm [&>*]:bg-gradient-to-r [&>*]:from-blue-400 [&>*]:to-purple-400"
        />
        <p className="mt-2 text-center text-sm text-white/60">{simulationProgress}% complete</p>
      </motion.div>
    </div>
  )
}
