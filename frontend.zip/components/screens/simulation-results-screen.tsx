"use client"

import { useState } from "react"
import type { AppState } from "@/hooks/use-app-state"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import GlassCard from "@/components/ui/glass-card"
import { ArrowLeft, DollarSign, Calendar, ChevronDown, ChevronUp, CreditCard, TrendingDown, Home } from "lucide-react"

const getMockResults = (simulationId: string, demographic: string) => {
  if (simulationId === "debt-payoff") {
    return demographic === "genz"
      ? [
          {
            id: "debt-elimination",
            title: "Debt Elimination Timeline",
            currentValue: "$29,700",
            projectedValue: "$0",
            timeframe: "18 months",
            monthlyContribution: "$600",
            confidence: 92,
            insights: [
              "Using debt avalanche method saves $2,400 in interest",
              "Student loan forgiveness programs could reduce timeline by 6 months",
              "Side income of $200/month accelerates payoff by 4 months",
            ],
          },
        ]
      : [
          {
            id: "debt-elimination",
            title: "Debt Elimination Timeline",
            currentValue: "$16,034",
            projectedValue: "$0",
            timeframe: "14 months",
            monthlyContribution: "$1,200",
            confidence: 95,
            insights: [
              "Using debt avalanche method saves $1,800 in interest",
              "Balance transfer to 0% APR card could save additional $800",
              "Current payment capacity allows for aggressive payoff strategy",
            ],
          },
        ]
  } else if (simulationId === "home-purchase") {
    return demographic === "genz"
      ? [
          {
            id: "home-purchase-plan",
            title: "Home Purchase Timeline",
            currentValue: "$8,000",
            projectedValue: "$40,000",
            timeframe: "24 months",
            monthlyContribution: "$1,333",
            confidence: 88,
            insights: [
              "First-time buyer programs could reduce down payment to $20,000",
              "Current savings rate of 20% supports your homeownership goal",
              "Consider FHA loan with 3.5% down payment option",
            ],
          },
        ]
      : [
          {
            id: "home-purchase-plan",
            title: "Home Purchase Timeline",
            currentValue: "$25,000",
            projectedValue: "$60,000",
            timeframe: "18 months",
            monthlyContribution: "$1,944",
            confidence: 94,
            insights: [
              "Your income supports a $400,000 home purchase comfortably",
              "Current interest rates favor buying over renting in your market",
              "Consider 15-year mortgage to save $80,000 in interest over loan term",
            ],
          },
        ]
  }

  // Default results for other simulations
  return [
    {
      id: "retirement",
      title: "Retirement Planning",
      currentValue: "$45,000",
      projectedValue: "$1.2M",
      timeframe: "30 years",
      monthlyContribution: "$500",
      confidence: 85,
      insights: [
        "Increase 401k contribution by 2% to maximize employer match",
        "Consider Roth IRA conversion for tax diversification",
        "Rebalance portfolio quarterly for optimal growth",
      ],
    },
    {
      id: "house",
      title: "Home Purchase",
      currentValue: "$15,000",
      projectedValue: "$80,000",
      timeframe: "5 years",
      monthlyContribution: "$1,200",
      confidence: 92,
      insights: [
        "You're on track to afford a $400k home in your target area",
        "Consider house hacking to reduce living expenses",
        "Lock in current interest rates if planning to buy soon",
      ],
    },
  ]
}

const getAIActionPlans = (simulationId: string, demographic: string) => {
  if (simulationId === "debt-payoff") {
    return [
      {
        id: "avalanche-plan",
        title: "Debt Avalanche Strategy",
        description: "Pay highest interest rates first for maximum savings",
        tag: "Mathematically Optimal",
        tagColor: "bg-blue-500/20 text-blue-300",
        potentialSaving: demographic === "genz" ? 2400 : 1800,
        rationale:
          "By focusing on high-interest debt first, you'll save the most money in interest payments. This method is mathematically proven to be the most cost-effective debt elimination strategy.",
        steps: [
          "List all debts by interest rate (highest first)",
          "Pay minimums on all debts except highest rate",
          "Put all extra money toward highest interest debt",
          "Repeat process until completely debt-free",
        ],
      },
      {
        id: "snowball-plan",
        title: "Debt Snowball Method",
        description: "Build momentum by paying smallest balances first",
        tag: "Psychologically Motivating",
        tagColor: "bg-green-500/20 text-green-300",
        potentialSaving: demographic === "genz" ? 1800 : 1200,
        rationale:
          "This method provides psychological wins through quick victories. By eliminating smaller debts first, you build momentum and motivation to tackle larger debts, leading to better long-term adherence.",
        steps: [
          "List all debts by balance (smallest first)",
          "Pay minimums on all debts except smallest",
          "Put all extra money toward smallest debt",
          "Celebrate wins and build momentum",
        ],
      },
      {
        id: "hybrid-plan",
        title: "Hybrid Debt Strategy",
        description: "Balance mathematical efficiency with psychological wins",
        tag: "Balanced Approach",
        tagColor: "bg-purple-500/20 text-purple-300",
        potentialSaving: demographic === "genz" ? 2100 : 1500,
        rationale:
          "This approach combines the psychological benefits of early wins with the mathematical efficiency of the avalanche method, providing both motivation and optimal savings for sustained success.",
        steps: [
          "Start with one small debt for quick psychological win",
          "Switch to avalanche method after first payoff",
          "Maintain motivation with milestone rewards",
          "Adjust strategy based on progress and motivation",
        ],
      },
    ]
  } else if (simulationId === "home-purchase") {
    return [
      {
        id: "aggressive-savings-plan",
        title: "Aggressive Savings Strategy",
        description: "Maximize savings rate for faster homeownership",
        tag: "Fast Track",
        tagColor: "bg-green-500/20 text-green-300",
        potentialSaving: demographic === "genz" ? 6 : 8,
        rationale:
          "By dramatically increasing your savings rate and cutting discretionary spending, you can reach your down payment goal months ahead of schedule. This approach requires discipline but gets you into homeownership faster.",
        steps: [
          "Increase savings rate to 30% of income",
          "Move down payment fund to high-yield savings account",
          "Reduce discretionary spending by 40%",
          "Consider side income opportunities for extra savings",
        ],
      },
      {
        id: "first-time-buyer-plan",
        title: "First-Time Buyer Programs",
        description: "Leverage programs and lower down payment options",
        tag: "Smart Financing",
        tagColor: "bg-blue-500/20 text-blue-300",
        potentialSaving: demographic === "genz" ? 15000 : 20000,
        rationale:
          "First-time buyer programs can significantly reduce your down payment requirements and provide additional assistance, making homeownership accessible sooner with less savings required upfront.",
        steps: [
          "Research first-time homebuyer programs in your area",
          "Consider FHA loan with 3.5% down payment option",
          "Look into down payment assistance programs",
          "Get pre-approved to strengthen your offers",
        ],
      },
      {
        id: "investment-plan",
        title: "Investment-Backed Strategy",
        description: "Grow your down payment through strategic investments",
        tag: "Growth Focused",
        tagColor: "bg-purple-500/20 text-purple-300",
        potentialSaving: demographic === "genz" ? 8000 : 12000,
        rationale:
          "By investing a portion of your down payment savings in diversified index funds, you can potentially grow your funds faster than traditional savings accounts, though this comes with market risk.",
        steps: [
          "Invest 70% of down payment savings in index funds",
          "Keep 30% in high-yield savings for stability",
          "Dollar-cost average monthly contributions",
          "Monitor market conditions and adjust allocation as needed",
        ],
      },
    ]
  }

  // Default action plans for other simulations
  return [
    {
      id: "conservative-plan",
      title: "Conservative Approach",
      description: "Low-risk strategies with steady returns",
      tag: "Conservative",
      tagColor: "bg-green-500/20 text-green-300",
      potentialSaving: 180,
      rationale:
        "Focus on guaranteed returns through high-yield savings and conservative investments. This approach minimizes risk while ensuring steady progress toward your goals.",
      steps: [
        "Move to high-yield savings account",
        "Increase 401k contribution by 1%",
        "Set up automated transfers for consistency",
        "Review and adjust quarterly",
      ],
    },
    {
      id: "balanced-plan",
      title: "Balanced Strategy",
      description: "Moderate risk with diversified portfolio",
      tag: "Balanced",
      tagColor: "bg-blue-500/20 text-blue-300",
      potentialSaving: 320,
      rationale:
        "Combine safe investments with moderate-risk options for balanced growth. This strategy offers good returns while maintaining reasonable risk levels.",
      steps: [
        "Diversify investment portfolio",
        "Increase 401k contribution by 3%",
        "Add index fund investments",
        "Monitor performance monthly",
      ],
    },
    {
      id: "aggressive-plan",
      title: "Aggressive Growth",
      description: "Higher risk for maximum potential returns",
      tag: "Aggressive",
      tagColor: "bg-red-500/20 text-red-300",
      potentialSaving: 480,
      rationale:
        "Maximize growth potential through higher-risk investments and aggressive savings rates. Best for those with longer time horizons and higher risk tolerance.",
      steps: [
        "Maximize 401k contributions to limit",
        "Invest in growth stocks and ETFs",
        "Consider real estate investment opportunities",
        "Review and rebalance monthly",
      ],
    },
  ]
}

export default function SimulationResultsScreen({ setCurrentScreen, currentSimulation, demographic }: AppState) {
  const [expandedPlans, setExpandedPlans] = useState<string[]>([])

  const mockResults = getMockResults(currentSimulation?.id || "", demographic)
  const aiActionPlans = getAIActionPlans(currentSimulation?.id || "", demographic)

  const togglePlanExpansion = (planId: string) => {
    setExpandedPlans((prev) => (prev.includes(planId) ? prev.filter((id) => id !== planId) : [...prev, planId]))
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring" } },
  }

  const getResultIcon = (simulationId: string) => {
    if (simulationId === "debt-payoff") return <CreditCard className="h-5 w-5" />
    if (simulationId === "home-purchase") return <Home className="h-5 w-5" />
    return <TrendingDown className="h-5 w-5" />
  }

  return (
    <div className="pb-28">
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-6 flex items-center gap-4"
      >
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCurrentScreen("simulations")}
          className="text-white hover:bg-white/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-white">Simulation Results</h1>
          <p className="text-gray-400">Your personalized financial projections</p>
        </div>
      </motion.header>

      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="px-4 space-y-6">
        {/* Results Overview */}
        {mockResults.map((result) => (
          <motion.div key={result.id} variants={itemVariants}>
            <GlassCard
              className={`${
                currentSimulation?.id === "debt-payoff"
                  ? "bg-gradient-to-r from-green-500/10 to-blue-500/10"
                  : currentSimulation?.id === "home-purchase"
                    ? "bg-gradient-to-r from-blue-500/10 to-purple-500/10"
                    : "bg-gradient-to-r from-blue-500/10 to-purple-500/10"
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                  {getResultIcon(currentSimulation?.id || "")}
                  {result.title}
                </h3>
                <div className="text-right">
                  <p className="text-sm text-gray-400">Confidence</p>
                  <p className="text-lg font-bold text-green-400">{result.confidence}%</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-400 mb-1">
                    {currentSimulation?.id === "debt-payoff"
                      ? "Current Debt"
                      : currentSimulation?.id === "home-purchase"
                        ? "Current Savings"
                        : "Current Value"}
                  </p>
                  <p className="text-2xl font-bold text-white">{result.currentValue}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">
                    {currentSimulation?.id === "debt-payoff"
                      ? "Target Balance"
                      : currentSimulation?.id === "home-purchase"
                        ? "Down Payment Goal"
                        : "Projected Value"}
                  </p>
                  <p
                    className={`text-2xl font-bold ${
                      currentSimulation?.id === "debt-payoff" ? "text-green-400" : "text-green-400"
                    }`}
                  >
                    {result.projectedValue}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-6 text-sm text-gray-300">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>{result.timeframe}</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  <span>{result.monthlyContribution}/month</span>
                </div>
              </div>

              {/* Key Insights */}
              <div className="mt-4 pt-4 border-t border-white/10">
                <h4 className="text-sm font-semibold text-white mb-2">Key Insights</h4>
                <div className="space-y-2">
                  {result.insights.map((insight, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <span className="text-blue-400 text-sm mt-1">•</span>
                      <p className="text-sm text-gray-300">{insight}</p>
                    </div>
                  ))}
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}

        {/* AI Action Plans */}
        <motion.div variants={itemVariants}>
          <h2 className="text-xl font-semibold text-white mb-4 px-2">
            {currentSimulation?.id === "debt-payoff"
              ? "Debt Elimination Strategies"
              : currentSimulation?.id === "home-purchase"
                ? "Homeownership Strategies"
                : "Suggested AI Action Plans"}
          </h2>
          <div className="space-y-4">
            {aiActionPlans.map((plan) => {
              const isExpanded = expandedPlans.includes(plan.id)
              return (
                <GlassCard key={plan.id} className="bg-white/5">
                  <div className="mb-3">
                    <span className={`inline-block px-2 py-1 text-xs rounded-full mb-2 ${plan.tagColor}`}>
                      {plan.tag}
                    </span>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-white">{plan.title}</h3>
                        <p className="text-sm text-gray-400 mt-1">{plan.description}</p>
                      </div>
                      <div className="text-right ml-4">
                        <p className="text-lg font-bold text-green-400">
                          {currentSimulation?.id === "debt-payoff"
                            ? `$${plan.potentialSaving} saved`
                            : currentSimulation?.id === "home-purchase"
                              ? typeof plan.potentialSaving === "number" && plan.potentialSaving > 1000
                                ? `$${plan.potentialSaving.toLocaleString()} less needed`
                                : `${plan.potentialSaving} months faster`
                              : `+$${plan.potentialSaving}/mo`}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="p-4 rounded-xl bg-black/20">
                      <button
                        onClick={() => togglePlanExpansion(plan.id)}
                        className="flex items-center justify-between w-full text-left"
                      >
                        <span className="text-sm text-gray-400 hover:text-white transition-colors">
                          Why we suggest this
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-gray-400" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-gray-400" />
                        )}
                      </button>

                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="mt-4 space-y-4"
                        >
                          <div>
                            <h4 className="text-purple-400 text-sm font-medium mb-2">Why This Recommendation</h4>
                            <p className="text-sm text-gray-300">{plan.rationale}</p>
                          </div>

                          <div>
                            <h4 className="text-purple-400 text-sm font-medium mb-2">Specific Data Analysis</h4>
                            <div className="space-y-2">
                              {plan.steps.map((step, stepIndex) => (
                                <div key={stepIndex} className="flex items-start gap-2">
                                  <span className="text-gray-400 text-sm mt-1">•</span>
                                  <p className="text-sm text-gray-300">{step}</p>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h4 className="text-purple-400 text-sm font-medium mb-2">Expected Results</h4>
                            <p className="text-sm text-gray-300">
                              {currentSimulation?.id === "debt-payoff"
                                ? `Save $${plan.potentialSaving} in interest payments with this approach`
                                : currentSimulation?.id === "home-purchase"
                                  ? typeof plan.potentialSaving === "number" && plan.potentialSaving > 1000
                                    ? `Reduce down payment requirement by $${plan.potentialSaving.toLocaleString()} with this approach`
                                    : `Reach your homeownership goal ${plan.potentialSaving} months faster with this approach`
                                  : `+$${plan.potentialSaving}/month additional savings with this approach`}
                            </p>
                          </div>

                          <Button
                            size="sm"
                            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
                          >
                            Dive Deep
                          </Button>
                        </motion.div>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Accept plan
                    </Button>
                    <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                      Cancel
                    </Button>
                  </div>
                </GlassCard>
              )
            })}
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}
