"use client"

import { useState } from "react"
import type { AppState } from "@/hooks/use-app-state"
import { ChevronLeft, Shield, Search, Check, RefreshCw, Lock } from "lucide-react"
import { motion } from "framer-motion"
import GlassCard from "@/components/ui/glass-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { popularInstitutions } from "@/lib/data"
import Image from "next/image"

export default function ConnectAccountScreen({ setCurrentScreen }: AppState) {
  const [selectedInstitution, setSelectedInstitution] = useState(null)
  const [isConnecting, setIsConnecting] = useState(false)

  const handleSelect = (inst) => {
    setSelectedInstitution(inst)
    setIsConnecting(true)
    setTimeout(() => {
      setIsConnecting(false)
      setCurrentScreen("profile")
    }, 3500)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  }

  if (isConnecting && selectedInstitution) {
    return (
      <div className="flex h-full items-center justify-center p-4">
        <GlassCard className="w-full max-w-sm bg-white/90 text-center text-foreground">
          <div
            className={`mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-2xl p-2 ${selectedInstitution.color}`}
          >
            <Image
              src={selectedInstitution.logo || "/placeholder.svg"}
              alt={selectedInstitution.name}
              width={48}
              height={48}
            />
          </div>
          <h2 className="mb-2 text-xl font-bold">Connecting to {selectedInstitution.name}</h2>
          <p className="mb-6 text-gray-600">Please wait, this may take a moment...</p>
          <div className="space-y-3 text-left">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex items-center gap-3"
            >
              <Check className="h-6 w-6 text-green-500" />
              <span>Secure connection established</span>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="flex items-center gap-3"
            >
              <RefreshCw className="h-6 w-6 animate-spin text-blue-500" />
              <span>Verifying credentials</span>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2.5 }}
              className="flex items-center gap-3 text-gray-400"
            >
              <Lock className="h-6 w-6" />
              <span>Syncing account data</span>
            </motion.div>
          </div>
        </GlassCard>
      </div>
    )
  }

  return (
    <div className="flex h-full flex-col">
      <header className="p-4 text-white">
        <Button onClick={() => setCurrentScreen("profile")} variant="ghost" className="hover:bg-white/20">
          <ChevronLeft className="mr-2 h-5 w-5" />
          Back to Profile
        </Button>
      </header>
      <div className="flex-1 overflow-y-auto p-4">
        <h1 className="mb-4 text-2xl font-bold text-white">Connect an Account</h1>
        <div className="relative mb-6">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <Input placeholder="Search for your bank" className="pl-10" />
        </div>

        <h2 className="mb-3 font-semibold text-white">Popular Institutions</h2>
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-3 gap-3">
          {popularInstitutions.map((inst) => (
            <motion.div key={inst.id} variants={itemVariants}>
              <GlassCard
                onClick={() => handleSelect(inst)}
                className="cursor-pointer bg-white/80 p-4 text-center text-foreground"
              >
                <div className={`mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-xl p-1 ${inst.color}`}>
                  <Image src={inst.logo || "/placeholder.svg"} alt={inst.name} width={32} height={32} />
                </div>
                <p className="text-sm font-medium">{inst.name}</p>
              </GlassCard>
            </motion.div>
          ))}
        </motion.div>

        <div className="mt-8">
          <GlassCard className="flex items-start gap-3 bg-blue-500/20 text-white">
            <Shield className="h-5 w-5 flex-shrink-0 text-blue-300" />
            <div>
              <h3 className="font-semibold">Your data is secure</h3>
              <p className="text-sm text-white/80">
                We use bank-level encryption and never store your login credentials.
              </p>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}
