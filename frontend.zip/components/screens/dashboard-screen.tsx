"use client"

import { useState, useEffect } from "react"
import type { AppState } from "@/hooks/use-app-state"
import { User, TrendingUp, Zap, ShieldCheck, ChevronUp, AlertTriangle, ChevronDown } from "lucide-react"
import { motion } from "framer-motion"
import GlassCard from "@/components/ui/glass-card"
import { Button } from "@/components/ui/button"
import AutomationStatusCard from "@/components/ui/automation-status-card"
import AIChatDrawer from "@/components/ui/ai-chat-drawer"

const demographicData = {
  genz: {
    label: "Gen Z",
    creditScore: 650,
    lastMonthScore: 627,
    creditInsight: "Credit utilization decreased from 45% to 38%",
  },
  millennial: {
    label: "Millennial",
    creditScore: 780,
    lastMonthScore: 757,
    creditInsight: "Payment history improved with on-time payments",
  },
}

export default function DashboardScreen({
  activeAutomations,
  setCurrentScreen,
  accounts,
  aiActions,
  setSelectedAction,
  demographic,
  setDemographic,
  isAIChatOpen,
  setAIChatOpen,
  selectedActionForChat,
  setSelectedActionForChat,
  monthlySpending,
}: AppState) {
  const [insight, setInsight] = useState("")
  const [isLoadingInsight, setIsLoadingInsight] = useState(true)
  const [expandedActions, setExpandedActions] = useState<string[]>([])

  const assets = accounts.filter((acc) => acc.type === "asset")
  const liabilities = accounts.filter((acc) => acc.type === "liability")
  const totalAssets = assets.reduce((sum, acc) => sum + acc.balance, 0)
  const totalLiabilities = Math.abs(liabilities.reduce((sum, acc) => sum + acc.balance, 0))
  const netWorth = totalAssets - totalLiabilities

  const currentCreditData = demographicData[demographic]
  const creditChange = currentCreditData.creditScore - currentCreditData.lastMonthScore

  const toggleActionExpansion = (actionId: string) => {
    setExpandedActions((prev) => (prev.includes(actionId) ? prev.filter((id) => id !== actionId) : [...prev, actionId]))
  }

  const handleAIChat = (action: any) => {
    setSelectedActionForChat(action)
    setAIChatOpen(true)
  }

  useEffect(() => {
    const fetchInsight = async () => {
      setIsLoadingInsight(true)
      try {
        const response = await fetch("/api/ai/insight")
        const data = await response.json()
        setInsight(data.insight)
      } catch (error) {
        console.error("Failed to fetch insight:", error)
        setInsight("Could not load AI insight at this time.")
      } finally {
        setIsLoadingInsight(false)
      }
    }

    fetchInsight()
  }, [])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring" } },
  }

  return (
    <div className="p-6 pb-28">
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 flex items-center justify-between relative z-50"
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-blue-500 shadow-lg shadow-purple-500/30 w-9 h-9">
            <Zap className="h-6 w-6" />
          </div>
          <div>
            <h1 className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-2xl font-bold text-transparent">
              FinanceAI
            </h1>
          </div>
        </div>
        <Button
          size="icon"
          variant="ghost"
          onClick={() => setCurrentScreen("profile")}
          className="rounded-xl border border-white/10 bg-white/5 backdrop-blur-lg hover:bg-white/10"
        >
          <User className="h-5 w-5" />
        </Button>
      </motion.header>

      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
        {/* Net Worth Card with Assets/Liabilities */}
        <motion.div variants={itemVariants}>
          <GlassCard className="cursor-pointer" onClick={() => setCurrentScreen("net-worth-detail")}>
            <div className="text-left mb-4">
              <p className="mb-2 text-sm text-gray-400">Total Net Worth</p>
              <p className="mb-2 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-4xl font-bold text-transparent">
                ${netWorth.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-3 w-3 text-green-400" />
                <span className="text-xs font-medium text-green-400">
                  {demographic === "genz" ? "8.5% YOY" : "12.3% YOY"}
                </span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Assets</span>
                <span className="text-lg font-bold text-green-400">
                  ${totalAssets.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Liabilities</span>
                <span className="text-lg font-bold text-red-400">
                  ${totalLiabilities.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                </span>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Suggested AI Actions */}
        <motion.div variants={itemVariants}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white flex items-center gap-2">
              <Zap className="h-5 w-5 text-purple-400" />
              Suggested AI Actions
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen("ai-actions")}
              className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
            >
              View all
            </Button>
          </div>
          <div className="space-y-4">
            {aiActions.slice(0, 2).map((action) => {
              const isExpanded = expandedActions.includes(action.id)
              return (
                <GlassCard key={action.id} className="bg-white/5">
                  <div className="mb-3">
                    <span className="inline-block px-2 py-1 text-xs bg-orange-500/20 text-orange-300 rounded-full mb-2">
                      Pending Approval
                    </span>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-white">{action.title}</h3>
                        <p className="text-sm text-gray-400 mt-1">{action.description}</p>
                      </div>
                      <div className="text-right ml-4">
                        <p className="text-lg font-bold text-green-400">+${action.potentialSaving}/mo</p>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="p-4 rounded-xl bg-black/20">
                      <button
                        onClick={() => toggleActionExpansion(action.id)}
                        className="flex items-center justify-between w-full text-left"
                      >
                        <span className="text-sm text-gray-400 hover:text-white transition-colors">
                          Why we suggest this
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-gray-400" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-gray-400" />
                        )}
                      </button>

                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="mt-4 space-y-4"
                        >
                          <div>
                            <h4 className="text-purple-400 text-sm font-medium mb-2">Why This Recommendation</h4>
                            <p className="text-sm text-gray-300">
                              {demographic === "genz"
                                ? "Your Chase savings account (****5200) is earning 0.01% APY while Marcus currently offers 4.5% APY on savings accounts"
                                : "Your Chase checking account (****5847) has excess funds earning 0.01% APY while Marcus currently offers 4.5% APY on high-yield savings"}
                            </p>
                          </div>

                          <div>
                            <h4 className="text-purple-400 text-sm font-medium mb-2">Specific Data Analysis</h4>
                            <p className="text-sm text-gray-300">
                              {demographic === "genz"
                                ? "Chase savings balance: $5,200 at 0.01% APY, Marcus current rate: 4.5% APY, potential transfer: $5,200"
                                : "Chase checking balance: $15,847 at 0.01% APY, Marcus current rate: 4.5% APY, potential transfer: $3,200"}
                            </p>
                          </div>

                          <div>
                            <h4 className="text-purple-400 text-sm font-medium mb-2">Expected Results</h4>
                            <p className="text-sm text-gray-300">
                              +${action.potentialSaving}/month additional interest income with no risk
                            </p>
                          </div>

                          <Button
                            size="sm"
                            onClick={() => handleAIChat(action)}
                            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
                          >
                            Dive Deep
                          </Button>
                        </motion.div>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Automate
                    </Button>
                    <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                      Cancel
                    </Button>
                  </div>
                </GlassCard>
              )
            })}
          </div>
        </motion.div>

        {/* AI Insights */}
        <motion.div variants={itemVariants}>
          <h2 className="text-xl font-semibold text-white mb-4">AI Insights</h2>
          <div className="space-y-4">
            {/* Spending Insights Card */}
            <GlassCard
              className="bg-gradient-to-r from-orange-500/10 to-red-500/10 cursor-pointer"
              onClick={() => setCurrentScreen("spend-tracking")}
            >
              <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-orange-400" />
                Spending Insights
              </h3>
              <div className="mb-3">
                <p className="text-xl font-bold text-white">
                  ${monthlySpending.total.toLocaleString()} spent this month
                </p>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-xl bg-white/5">
                <AlertTriangle className="h-5 w-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">
                    {demographic === "genz" ? "Food & Dining Alert" : "Shopping Alert"}
                  </p>
                  <p className="text-sm text-gray-300">
                    {demographic === "genz"
                      ? "You're spending 12% more on food this month."
                      : "You're spending 17% more on shopping this month."}
                  </p>
                </div>
              </div>
            </GlassCard>

            {/* Credit Score Insights Card */}
            <GlassCard className="cursor-pointer" onClick={() => setCurrentScreen("credit-score")}>
              <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-green-400" />
                Credit Score Insights
              </h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div>
                    <p className="font-semibold text-white">Credit Score</p>
                    <p className="text-xs text-gray-400 max-w-48">
                      +{creditChange} this month, {currentCreditData.creditInsight}
                    </p>
                  </div>
                </div>
                <p
                  className={`text-2xl font-bold ${
                    currentCreditData.creditScore >= 750
                      ? "text-green-400"
                      : currentCreditData.creditScore >= 650
                        ? "text-yellow-400"
                        : "text-red-400"
                  }`}
                >
                  {currentCreditData.creditScore}
                </p>
              </div>
            </GlassCard>
          </div>
        </motion.div>

        {activeAutomations.length > 0 && (
          <motion.div variants={itemVariants} className="space-y-4">
            <h2 className="px-1 text-lg font-semibold text-white">Active Automations</h2>
            {activeAutomations.map((automation, index) => (
              <AutomationStatusCard key={index} automation={automation} />
            ))}
          </motion.div>
        )}
      </motion.div>

      <AIChatDrawer isOpen={isAIChatOpen} onClose={() => setAIChatOpen(false)} selectedAction={selectedActionForChat} />
    </div>
  )
}
