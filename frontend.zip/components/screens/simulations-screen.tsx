"use client"

import type { AppState } from "@/hooks/use-app-state"
import { Sparkles, Briefcase, Home, TrendingDown, DollarSign, Star, CreditCard } from "lucide-react"
import { motion } from "framer-motion"
import GlassCard from "@/components/ui/glass-card"

const recommendedSimulations = [
  {
    id: "job-loss",
    title: "Job Loss Scenario",
    subtitle: "How long can you survive without income?",
    icon: <Briefcase className="h-8 w-8" />,
    color: "from-red-500/20 to-orange-500/20",
    borderColor: "border-red-500/30",
  },
  {
    id: "debt-payoff",
    title: "Debt Payoff Strategy",
    subtitle: "Optimize your path to becoming debt-free",
    icon: <CreditCard className="h-8 w-8" />,
    color: "from-green-500/20 to-blue-500/20",
    borderColor: "border-green-500/30",
  },
  {
    id: "home-purchase",
    title: "Home Purchase Planning",
    subtitle: "Plan your path to homeownership",
    icon: <Home className="h-8 w-8" />,
    color: "from-blue-500/20 to-purple-500/20",
    borderColor: "border-blue-500/30",
  },
]

const otherSimulations = [
  {
    id: "market-crash",
    title: "Market Crash Impact",
    subtitle: "Portfolio resilience during economic downturns",
    icon: <TrendingDown className="h-8 w-8" />,
    color: "from-purple-500/20 to-red-500/20",
    borderColor: "border-purple-500/30",
    disabled: true,
  },
  {
    id: "salary-increase",
    title: "Salary Increase",
    subtitle: "Optimize your financial strategy with higher income",
    icon: <DollarSign className="h-8 w-8" />,
    color: "from-green-500/20 to-blue-500/20",
    borderColor: "border-green-500/30",
    disabled: true,
  },
]

export default function SimulationsScreen({ setCurrentScreen, setCurrentSimulation }: AppState) {
  const handleSimulationClick = (simulation: any) => {
    if (simulation.disabled) return
    setCurrentSimulation(simulation)
    setCurrentScreen("simulation-setup")
  }

  return (
    <div className="flex h-full flex-col pb-28">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="p-6 text-white">
        <h1 className="text-2xl font-semibold mb-2">Financial Simulations</h1>
        <p className="text-sm text-white/80">Run scenarios to understand your financial resilience</p>
      </motion.div>

      {/* Simulation Cards */}
      <div className="flex-1 overflow-y-auto px-4 space-y-6">
        {/* Recommended for You */}
        <div>
          <h2 className="mb-3 flex items-center gap-2 font-semibold text-white">
            <Star className="h-5 w-5 text-yellow-400" />
            Recommended for You
          </h2>

          <div className="space-y-4">
            {recommendedSimulations.map((sim, i) => (
              <motion.div
                key={sim.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0, transition: { delay: i * 0.1 } }}
              >
                <GlassCard
                  onClick={() => handleSimulationClick(sim)}
                  className={`cursor-pointer bg-gradient-to-r ${sim.color} border-2 ${sim.borderColor} hover:scale-[1.02] transition-all duration-200`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white">
                      {sim.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-1">{sim.title}</h3>
                      <p className="text-sm text-gray-300">{sim.subtitle}</p>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Other Simulations */}
        <div>
          <h2 className="mb-3 flex items-center gap-2 font-semibold text-white">
            <Sparkles className="h-5 w-5 text-blue-400" />
            Other Simulations
          </h2>

          <div className="space-y-4">
            {otherSimulations.map((sim, i) => (
              <motion.div
                key={sim.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0, transition: { delay: (i + 3) * 0.1 } }}
              >
                <GlassCard
                  className={`bg-gradient-to-r ${sim.color} border-2 ${sim.borderColor} ${
                    sim.disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:scale-[1.02]"
                  } transition-all duration-200`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white">
                      {sim.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-1">{sim.title}</h3>
                      <p className="text-sm text-gray-300">{sim.subtitle}</p>
                      {sim.disabled && <p className="text-xs text-gray-500 mt-2">Coming soon</p>}
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
