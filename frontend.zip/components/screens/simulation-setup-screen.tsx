"use client"

import { useState, useEffect } from "react"
import type { AppState, SimulationParameter } from "@/hooks/use-app-state"
import { ChevronLeft, Loader, Bot, ChevronDown, ChevronUp } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import GlassCard from "@/components/ui/glass-card"

const getLoadingSteps = (simulationId: string) => {
  if (simulationId === "job-loss") {
    return [
      "Fetching average spending numbers...",
      "Analyzing bank balances from connected accounts...",
      "Researching average job search time for your role...",
      "Calculating emergency fund requirements...",
      "Preparing simulation parameters...",
    ]
  } else if (simulationId === "debt-payoff") {
    return [
      "Analyzing current debt balances...",
      "Calculating interest rates and minimum payments...",
      "Reviewing monthly income and expenses...",
      "Optimizing payoff strategies (avalanche vs snowball)...",
      "Preparing debt elimination timeline...",
    ]
  } else if (simulationId === "home-purchase") {
    return [
      "Analyzing current savings and income patterns...",
      "Fetching market interest rates for your credit score...",
      "Researching home prices in your target area...",
      "Calculating down payment requirements and closing costs...",
      "Preparing homeownership timeline projections...",
    ]
  }
  return ["Preparing simulation..."]
}

const getSimulationParameters = (simulationId: string, demographic: string): SimulationParameter[] => {
  if (simulationId === "job-loss") {
    return demographic === "genz"
      ? [
          {
            id: "monthly-expenses",
            name: "Monthly Expenses",
            value: 2100,
            min: 1500,
            max: 3000,
            unit: "$",
            description: "Your average monthly spending",
          },
          {
            id: "emergency-fund",
            name: "Emergency Fund",
            value: 5200,
            min: 1000,
            max: 15000,
            unit: "$",
            description: "Available emergency savings",
          },
          {
            id: "job-search-time",
            name: "Job Search Duration",
            value: 4,
            min: 1,
            max: 12,
            unit: "months",
            description: "Expected time to find new job",
          },
          {
            id: "unemployment-benefit",
            name: "Unemployment Benefits",
            value: 800,
            min: 0,
            max: 1500,
            unit: "$/month",
            description: "Monthly unemployment compensation",
          },
        ]
      : [
          {
            id: "monthly-expenses",
            name: "Monthly Expenses",
            value: 4200,
            min: 3000,
            max: 6000,
            unit: "$",
            description: "Your average monthly spending",
          },
          {
            id: "emergency-fund",
            name: "Emergency Fund",
            value: 35000,
            min: 10000,
            max: 80000,
            unit: "$",
            description: "Available emergency savings",
          },
          {
            id: "job-search-time",
            name: "Job Search Duration",
            value: 3,
            min: 1,
            max: 12,
            unit: "months",
            description: "Expected time to find new job",
          },
          {
            id: "unemployment-benefit",
            name: "Unemployment Benefits",
            value: 1200,
            min: 0,
            max: 2000,
            unit: "$/month",
            description: "Monthly unemployment compensation",
          },
        ]
  } else if (simulationId === "debt-payoff") {
    return demographic === "genz"
      ? [
          {
            id: "total-debt",
            name: "Total Debt Amount",
            value: 29700,
            min: 5000,
            max: 50000,
            unit: "$",
            description: "Combined student loans and credit card debt",
          },
          {
            id: "monthly-income",
            name: "Monthly Income",
            value: 3200,
            min: 2000,
            max: 5000,
            unit: "$",
            description: "Your monthly take-home income",
          },
          {
            id: "monthly-payment",
            name: "Monthly Payment Capacity",
            value: 600,
            min: 200,
            max: 1200,
            unit: "$",
            description: "Amount available for debt payments",
          },
          {
            id: "target-timeframe",
            name: "Target Payoff Time",
            value: 18,
            min: 12,
            max: 60,
            unit: "months",
            description: "Desired time to become debt-free",
          },
        ]
      : [
          {
            id: "total-debt",
            name: "Total Debt Amount",
            value: 16034,
            min: 5000,
            max: 50000,
            unit: "$",
            description: "Combined credit cards and remaining student loans",
          },
          {
            id: "monthly-income",
            name: "Monthly Income",
            value: 8500,
            min: 5000,
            max: 15000,
            unit: "$",
            description: "Your monthly take-home income",
          },
          {
            id: "monthly-payment",
            name: "Monthly Payment Capacity",
            value: 1200,
            min: 500,
            max: 3000,
            unit: "$",
            description: "Amount available for debt payments",
          },
          {
            id: "target-timeframe",
            name: "Target Payoff Time",
            value: 18,
            min: 6,
            max: 36,
            unit: "months",
            description: "Desired time to become debt-free",
          },
        ]
  } else if (simulationId === "home-purchase") {
    return demographic === "genz"
      ? [
          {
            id: "down-payment-goal",
            name: "Down Payment Goal",
            value: 40000,
            min: 20000,
            max: 100000,
            unit: "$",
            description: "Target down payment amount (typically 10-20% of home price)",
          },
          {
            id: "target-timeframe",
            name: "Target Timeframe",
            value: 24,
            min: 12,
            max: 60,
            unit: "months",
            description: "When you want to buy your home",
          },
          {
            id: "monthly-income",
            name: "Monthly Income",
            value: 3200,
            min: 2000,
            max: 8000,
            unit: "$",
            description: "Your monthly take-home income",
          },
          {
            id: "interest-rate",
            name: "Interest Rate",
            value: 7.2,
            min: 5.0,
            max: 9.0,
            unit: "%",
            description: "Expected mortgage interest rate based on your credit score",
          },
        ]
      : [
          {
            id: "down-payment-goal",
            name: "Down Payment Goal",
            value: 60000,
            min: 30000,
            max: 150000,
            unit: "$",
            description: "Target down payment amount (typically 10-20% of home price)",
          },
          {
            id: "target-timeframe",
            name: "Target Timeframe",
            value: 18,
            min: 6,
            max: 48,
            unit: "months",
            description: "When you want to buy your home",
          },
          {
            id: "monthly-income",
            name: "Monthly Income",
            value: 8500,
            min: 5000,
            max: 15000,
            unit: "$",
            description: "Your monthly take-home income",
          },
          {
            id: "interest-rate",
            name: "Interest Rate",
            value: 6.8,
            min: 5.0,
            max: 8.5,
            unit: "%",
            description: "Expected mortgage interest rate based on your credit score",
          },
        ]
  }
  return []
}

const calculateOutcome = (simulationId: string, parameters: SimulationParameter[]): string => {
  if (simulationId === "job-loss") {
    const monthlyExpenses = parameters.find((p) => p.id === "monthly-expenses")?.value || 0
    const emergencyFund = parameters.find((p) => p.id === "emergency-fund")?.value || 0
    const unemploymentBenefit = parameters.find((p) => p.id === "unemployment-benefit")?.value || 0

    if (monthlyExpenses === 0) return "0 months"

    const netMonthlyBurn = monthlyExpenses - unemploymentBenefit
    const runwayMonths = Math.floor(emergencyFund / netMonthlyBurn)
    return `${runwayMonths} months`
  } else if (simulationId === "debt-payoff") {
    const totalDebt = parameters.find((p) => p.id === "total-debt")?.value || 0
    const monthlyPayment = parameters.find((p) => p.id === "monthly-payment")?.value || 0
    const targetTimeframe = parameters.find((p) => p.id === "target-timeframe")?.value || 0

    if (monthlyPayment === 0) return "Unable to calculate"

    const calculatedMonths = Math.ceil(totalDebt / monthlyPayment)
    const isOnTrack = calculatedMonths <= targetTimeframe

    return isOnTrack ? `On track - ${targetTimeframe} months` : `${calculatedMonths} months needed`
  } else if (simulationId === "home-purchase") {
    const downPaymentGoal = parameters.find((p) => p.id === "down-payment-goal")?.value || 0
    const targetTimeframe = parameters.find((p) => p.id === "target-timeframe")?.value || 0
    const monthlyIncome = parameters.find((p) => p.id === "monthly-income")?.value || 0

    if (monthlyIncome === 0 || targetTimeframe === 0) return "Unable to calculate"

    // Assume 20% of income can be saved for down payment
    const monthlySavings = monthlyIncome * 0.2
    const totalSavings = monthlySavings * targetTimeframe
    const isOnTrack = totalSavings >= downPaymentGoal

    return isOnTrack ? `On Track` : `Need ${Math.ceil((downPaymentGoal - totalSavings) / monthlySavings)} more months`
  }
  return ""
}

const getOutcomeTitle = (simulationId: string): string => {
  if (simulationId === "job-loss") return "Financial Runway"
  if (simulationId === "debt-payoff") return "Payoff Timeline"
  if (simulationId === "home-purchase") return "Homeownership Goal"
  return "Outcome"
}

const getOutcomeDescription = (simulationId: string, outcome: string): string => {
  if (simulationId === "job-loss") {
    const months = outcome.split(" ")[0]
    return `You can survive without income for ${months} months with current parameters`
  } else if (simulationId === "debt-payoff") {
    if (outcome.includes("On track")) {
      return "You'll reach your debt-free goal within your target timeframe"
    } else {
      return "You'll need to adjust payments or timeline to meet your goal"
    }
  } else if (simulationId === "home-purchase") {
    if (outcome === "On Track") {
      return "You'll reach your down payment goal within your target timeframe"
    } else {
      return "You'll need to save more or extend your timeline to reach your goal"
    }
  }
  return ""
}

const formatParameterValue = (param: SimulationParameter): string => {
  if (param.unit === "$") {
    return `$${param.value.toLocaleString()}`
  } else if (param.unit === "$/month") {
    return `$${param.value.toLocaleString()}/month`
  } else if (param.unit === "months") {
    return `${param.value} ${param.value === 1 ? "month" : "months"}`
  } else if (param.unit === "%") {
    return `${param.value}%`
  }
  return `${param.value}${param.unit}`
}

const formatRangeValue = (value: number, unit: string): string => {
  if (unit === "$") {
    return `$${value.toLocaleString()}`
  } else if (unit === "$/month") {
    return `$${value.toLocaleString()}`
  } else if (unit === "months") {
    return `${value} ${value === 1 ? "mo" : "mos"}`
  } else if (unit === "%") {
    return `${value}%`
  }
  return `${value}${unit}`
}

const getAIActionPlans = (simulationId: string, demographic: string) => {
  if (simulationId === "debt-payoff") {
    return [
      {
        id: "avalanche",
        title: "Debt Avalanche Method",
        subtitle: "Pay highest interest rates first",
        tag: "Mathematically Optimal",
        tagColor: "bg-blue-500/20 text-blue-300",
        actions: [
          "List all debts by interest rate (highest first)",
          "Pay minimums on all debts except highest rate",
          "Put all extra money toward highest interest debt",
          "Repeat until debt-free",
        ],
        rationale:
          "This method saves the most money in interest payments over time. By targeting high-interest debt first, you minimize the total cost of your debt elimination journey.",
        potentialSaving: demographic === "genz" ? 2400 : 1800,
        buttonColor: "bg-blue-600 hover:bg-blue-700",
      },
      {
        id: "snowball",
        title: "Debt Snowball Method",
        subtitle: "Pay smallest balances first",
        tag: "Psychologically Motivating",
        tagColor: "bg-green-500/20 text-green-300",
        actions: [
          "List all debts by balance (smallest first)",
          "Pay minimums on all debts except smallest",
          "Put all extra money toward smallest debt",
          "Celebrate wins and build momentum",
        ],
        rationale:
          "This method provides psychological wins through quick victories. By eliminating smaller debts first, you build momentum and motivation to tackle larger debts.",
        potentialSaving: demographic === "genz" ? 1800 : 1200,
        buttonColor: "bg-green-600 hover:bg-green-700",
      },
      {
        id: "hybrid",
        title: "Hybrid Approach",
        subtitle: "Balance math and psychology",
        tag: "Balanced",
        tagColor: "bg-purple-500/20 text-purple-300",
        actions: [
          "Start with one small debt for quick win",
          "Switch to avalanche method after first payoff",
          "Maintain motivation with milestone rewards",
          "Adjust strategy based on progress",
        ],
        rationale:
          "This approach combines the psychological benefits of early wins with the mathematical efficiency of the avalanche method, providing both motivation and optimal savings.",
        potentialSaving: demographic === "genz" ? 2100 : 1500,
        buttonColor: "bg-purple-600 hover:bg-purple-700",
      },
    ]
  } else if (simulationId === "home-purchase") {
    return [
      {
        id: "aggressive-savings",
        title: "Aggressive Savings Plan",
        subtitle: "Maximize savings rate for faster homeownership",
        tag: "Fast Track",
        tagColor: "bg-green-500/20 text-green-300",
        actions: [
          "Increase savings rate to 30% of income",
          "Move to high-yield savings account for down payment fund",
          "Reduce discretionary spending by 40%",
          "Consider side income opportunities",
        ],
        rationale:
          "By dramatically increasing your savings rate, you can reach your down payment goal months ahead of schedule. This approach requires discipline but gets you into homeownership faster.",
        potentialSaving: demographic === "genz" ? 6 : 8,
        buttonColor: "bg-green-600 hover:bg-green-700",
      },
      {
        id: "first-time-buyer",
        title: "First-Time Buyer Strategy",
        subtitle: "Leverage programs and lower down payment options",
        tag: "Smart Financing",
        tagColor: "bg-blue-500/20 text-blue-300",
        actions: [
          "Research first-time homebuyer programs in your area",
          "Consider FHA loan with 3.5% down payment",
          "Look into down payment assistance programs",
          "Get pre-approved to strengthen offers",
        ],
        rationale:
          "First-time buyer programs can significantly reduce your down payment requirements and provide additional assistance, making homeownership accessible sooner with less savings.",
        potentialSaving: demographic === "genz" ? 15000 : 20000,
        buttonColor: "bg-blue-600 hover:bg-blue-700",
      },
      {
        id: "investment-approach",
        title: "Investment-Backed Strategy",
        subtitle: "Grow your down payment through investments",
        tag: "Growth Focused",
        tagColor: "bg-purple-500/20 text-purple-300",
        actions: [
          "Invest 70% of down payment savings in index funds",
          "Keep 30% in high-yield savings for stability",
          "Dollar-cost average monthly contributions",
          "Monitor market conditions and adjust allocation",
        ],
        rationale:
          "By investing a portion of your down payment savings, you can potentially grow your funds faster than traditional savings, though this comes with market risk.",
        potentialSaving: demographic === "genz" ? 8000 : 12000,
        buttonColor: "bg-purple-600 hover:bg-purple-700",
      },
    ]
  }

  // Default action plans for other simulations
  return [
    {
      id: "conservative",
      title: "Conservative Plan",
      subtitle: "Low risk, steady progress",
      tag: "Conservative",
      tagColor: "bg-green-500/20 text-green-300",
      actions: [
        "Increase savings rate from 15% to 20% of income",
        "Move $15K to high-yield savings account (2.6% APY)",
        "Cancel unused subscriptions to free up $67/month",
        "Set up automated transfers for consistency",
      ],
      rationale:
        "This plan focuses on building a solid financial foundation with minimal risk. By gradually increasing your savings rate and optimizing existing accounts, you create sustainable habits that compound over time.",
      potentialSaving: 67,
      buttonColor: "bg-green-600 hover:bg-green-700",
    },
    {
      id: "aggressive",
      title: "Aggressive Plan",
      subtitle: "Faster timeline, higher commitment",
      tag: "Aggressive",
      tagColor: "bg-red-500/20 text-red-300",
      actions: [
        "Increase savings rate to 30% of income",
        "Temporarily reduce investment contributions",
        "Take on freelance work for extra $500/month",
        "Reduce discretionary spending by 25%",
      ],
      rationale:
        "This plan maximizes your financial runway through significant lifestyle changes and additional income generation. It requires discipline but can dramatically improve your financial position in a shorter timeframe.",
      potentialSaving: 500,
      buttonColor: "bg-red-600 hover:bg-red-700",
    },
    {
      id: "balanced",
      title: "Balanced Plan",
      subtitle: "Moderate approach with flexibility",
      tag: "Balanced",
      tagColor: "bg-blue-500/20 text-blue-300",
      actions: [
        "Increase savings rate to 25% of income",
        "Optimize current accounts for better returns",
        "Use cashback rewards for down payment fund",
        "Review and negotiate bills quarterly",
      ],
      rationale:
        "This plan strikes a balance between aggressive savings and lifestyle maintenance. It provides steady progress toward your goals while maintaining flexibility for unexpected opportunities or challenges.",
      potentialSaving: 150,
      buttonColor: "bg-blue-600 hover:bg-blue-700",
    },
  ]
}

export default function SimulationSetupScreen({ currentSimulation, setCurrentScreen, demographic }: AppState) {
  const [isLoading, setIsLoading] = useState(true)
  const [currentStep, setCurrentStep] = useState(0)
  const [parameters, setParameters] = useState<SimulationParameter[]>([])
  const [expandedPlans, setExpandedPlans] = useState<string[]>([])

  const loadingSteps = getLoadingSteps(currentSimulation?.id || "")
  const outcome = calculateOutcome(currentSimulation?.id || "", parameters)
  const outcomeTitle = getOutcomeTitle(currentSimulation?.id || "")
  const outcomeDescription = getOutcomeDescription(currentSimulation?.id || "", outcome)
  const actionPlans = getAIActionPlans(currentSimulation?.id || "", demographic)

  const togglePlanExpansion = (planId: string) => {
    setExpandedPlans((prev) => (prev.includes(planId) ? prev.filter((id) => id !== planId) : [...prev, planId]))
  }

  useEffect(() => {
    if (currentSimulation) {
      setIsLoading(true)
      setCurrentStep(0)
      setParameters([])

      const interval = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev >= loadingSteps.length - 1) {
            clearInterval(interval)
            setTimeout(() => {
              const params = getSimulationParameters(currentSimulation.id, demographic)
              setParameters(params)
              setIsLoading(false)
            }, 100)
            return prev
          }
          return prev + 1
        })
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [currentSimulation, demographic, loadingSteps.length])

  const handleParameterChange = (paramId: string, value: number[]) => {
    setParameters((prev) => prev.map((param) => (param.id === paramId ? { ...param, value: value[0] } : param)))
  }

  if (!currentSimulation) {
    return (
      <div className="flex h-full items-center justify-center text-white">
        <p>No simulation selected. Please go back.</p>
        <Button onClick={() => setCurrentScreen("simulations")}>Go Back</Button>
      </div>
    )
  }

  return (
    <div className="pb-28">
      <header className="p-4">
        <Button
          onClick={() => setCurrentScreen("simulations")}
          variant="ghost"
          className="text-white hover:bg-white/20"
        >
          <ChevronLeft className="mr-2 h-5 w-5" />
          Back to Simulations
        </Button>
      </header>

      <div className="px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <h1 className="text-2xl font-bold text-white mb-2">{currentSimulation.title}</h1>
          <p className="text-gray-400">{currentSimulation.subtitle}</p>
        </motion.div>

        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <GlassCard className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 text-center">
                <div className="flex items-center justify-center mb-4">
                  <Loader className="h-8 w-8 animate-spin text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Preparing Simulation</h3>
                <p className="text-gray-300">{loadingSteps[currentStep]}</p>
                <div className="mt-4 w-full bg-gray-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-1000"
                    style={{ width: `${((currentStep + 1) / loadingSteps.length) * 100}%` }}
                  />
                </div>
              </GlassCard>
            </motion.div>
          ) : (
            <motion.div
              key="parameters"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Key Outcome Display */}
              <GlassCard
                className={`text-center ${
                  currentSimulation.id === "debt-payoff"
                    ? outcome.includes("On track")
                      ? "bg-gradient-to-r from-green-500/10 to-blue-500/10"
                      : "bg-gradient-to-r from-orange-500/10 to-red-500/10"
                    : currentSimulation.id === "home-purchase"
                      ? outcome === "On Track"
                        ? "bg-gradient-to-r from-green-500/10 to-blue-500/10"
                        : "bg-gradient-to-r from-orange-500/10 to-red-500/10"
                      : "bg-gradient-to-r from-green-500/10 to-blue-500/10"
                }`}
              >
                <h2 className="text-lg font-semibold text-white mb-2">{outcomeTitle}</h2>
                <p
                  className={`text-4xl font-bold mb-2 ${
                    currentSimulation.id === "debt-payoff"
                      ? outcome.includes("On track")
                        ? "text-green-400"
                        : "text-orange-400"
                      : currentSimulation.id === "home-purchase"
                        ? outcome === "On Track"
                          ? "text-green-400"
                          : "text-orange-400"
                        : "text-green-400"
                  }`}
                >
                  {outcome}
                </p>
                <p className="text-sm text-gray-400">{outcomeDescription}</p>
              </GlassCard>

              <h2 className="text-xl font-semibold text-white">Adjust Parameters</h2>

              {parameters.map((param, index) => (
                <motion.div
                  key={param.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0, transition: { delay: index * 0.1 } }}
                >
                  <GlassCard className="bg-white/5">
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold text-white">{param.name}</h3>
                        <span className="text-xl font-bold text-blue-400">{formatParameterValue(param)}</span>
                      </div>
                      <p className="text-sm text-gray-400 mb-4">{param.description}</p>

                      <div className="relative">
                        <Slider
                          value={[param.value]}
                          onValueChange={(value) => handleParameterChange(param.id, value)}
                          max={param.max}
                          min={param.min}
                          step={param.unit.includes("$") ? 1000 : param.unit === "%" ? 0.1 : 1}
                          className="w-full [&>span:first-child]:h-2 [&>span:first-child]:bg-gray-600 [&_[role=slider]]:bg-blue-500 [&_[role=slider]]:border-blue-400 [&_[role=slider]]:h-5 [&_[role=slider]]:w-5 [&>span:first-child>span]:bg-blue-500"
                        />
                      </div>

                      <div className="flex justify-between text-xs text-gray-500 mt-2">
                        <span>{formatRangeValue(param.min, param.unit)}</span>
                        <span>{formatRangeValue(param.max, param.unit)}</span>
                      </div>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}

              {/* AI Action Plans Section */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                  <Bot className="h-5 w-5 text-purple-400" />
                  AI Action Plans
                </h2>
                {actionPlans.map((plan, index) => {
                  const isExpanded = expandedPlans.includes(plan.id)
                  return (
                    <motion.div
                      key={plan.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0, transition: { delay: index * 0.1 } }}
                    >
                      <GlassCard className="bg-white/5">
                        <div className="mb-3">
                          <span className={`inline-block px-2 py-1 text-xs rounded-full mb-2 ${plan.tagColor}`}>
                            {plan.tag}
                          </span>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="text-lg font-semibold text-white">{plan.title}</h3>
                              <p className="text-sm text-gray-400 mt-1">{plan.subtitle}</p>
                            </div>
                            <div className="text-right ml-4">
                              <p className="text-lg font-bold text-green-400">
                                {currentSimulation.id === "debt-payoff"
                                  ? `$${plan.potentialSaving} saved`
                                  : currentSimulation.id === "home-purchase"
                                    ? typeof plan.potentialSaving === "number" && plan.potentialSaving > 1000
                                      ? `$${plan.potentialSaving.toLocaleString()} less needed`
                                      : `${plan.potentialSaving} months faster`
                                    : `+$${plan.potentialSaving}/mo`}
                              </p>
                            </div>
                          </div>
                        </div>

                        <div className="mb-4">
                          <button
                            onClick={() => togglePlanExpansion(plan.id)}
                            className="flex items-center justify-between w-full text-left p-4 rounded-xl bg-black/20 hover:bg-black/30 transition-colors"
                          >
                            <span className="text-sm text-gray-400 hover:text-white transition-colors">
                              Why we suggest this
                            </span>
                            {isExpanded ? (
                              <ChevronUp className="h-4 w-4 text-gray-400" />
                            ) : (
                              <ChevronDown className="h-4 w-4 text-gray-400" />
                            )}
                          </button>

                          {isExpanded && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="mt-4 px-4 pb-4"
                            >
                              <div className="space-y-4">
                                <div>
                                  <h4 className="text-purple-400 font-semibold mb-2">Why This Recommendation</h4>
                                  <p className="text-sm text-gray-300">{plan.rationale}</p>
                                </div>

                                <div>
                                  <h4 className="text-purple-400 font-semibold mb-2">Action Steps</h4>
                                  <div className="space-y-2">
                                    {plan.actions.map((action, actionIndex) => (
                                      <div key={actionIndex} className="flex items-start gap-2">
                                        <span className="text-gray-400 text-sm mt-1">•</span>
                                        <p className="text-sm text-gray-300">{action}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                <div>
                                  <h4 className="text-purple-400 font-semibold mb-2">Expected Results</h4>
                                  <p className="text-sm text-gray-300">
                                    {currentSimulation.id === "debt-payoff"
                                      ? `Save $${plan.potentialSaving} in interest payments with this approach`
                                      : currentSimulation.id === "home-purchase"
                                        ? typeof plan.potentialSaving === "number" && plan.potentialSaving > 1000
                                          ? `Reduce down payment requirement by $${plan.potentialSaving.toLocaleString()} with this approach`
                                          : `Reach your homeownership goal ${plan.potentialSaving} months faster with this approach`
                                        : `+$${plan.potentialSaving}/month additional savings with this approach`}
                                  </p>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" className={plan.buttonColor}>
                            Accept plan
                          </Button>
                          <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                            Cancel
                          </Button>
                        </div>
                      </GlassCard>
                    </motion.div>
                  )
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
