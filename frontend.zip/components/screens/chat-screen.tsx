"use client"

import { useState, useRef, useEffect } from "react"
import type { AppState } from "@/hooks/use-app-state"
import { motion, AnimatePresence } from "framer-motion"
import { X, Send, Bot, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Message {
  sender: "user" | "ai"
  text: string
}

export default function ChatScreen({ isChatOpen, setChatOpen }: AppState) {
  const [messages, setMessages] = useState<Message[]>([
    { sender: "ai", text: "Hello! How can I help you with your finances today?" },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<null | HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(scrollToBottom, [messages])

  const handleSend = async () => {
    if (!input.trim()) return
    const userMessage = { sender: "user", text: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        body: JSON.stringify({ message: input }),
      })
      const data = await response.json()
      const aiMessage = { sender: "ai", text: data.reply }
      setMessages((prev) => [...prev, aiMessage])
    } catch (error) {
      const errorMessage = { sender: "ai", text: "Sorry, I'm having trouble connecting. Please try again." }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  if (!isChatOpen) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col bg-black/80 backdrop-blur-xl"
    >
      <header className="flex items-center justify-between p-4 text-white">
        <h2 className="text-lg font-semibold">FinanceAI Assistant</h2>
        <Button size="icon" variant="ghost" onClick={() => setChatOpen(false)}>
          <X />
        </Button>
      </header>

      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        <AnimatePresence>
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex items-end gap-2 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.sender === "ai" && (
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-purple-500">
                  <Bot className="h-5 w-5 text-white" />
                </div>
              )}
              <div
                className={`max-w-xs rounded-2xl px-4 py-2 md:max-w-md ${
                  msg.sender === "user"
                    ? "rounded-br-none bg-blue-600 text-white"
                    : "rounded-bl-none bg-gray-700 text-gray-200"
                }`}
              >
                {msg.text}
              </div>
              {msg.sender === "user" && (
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gray-600">
                  <User className="h-5 w-5 text-white" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
        {isLoading && (
          <motion.div layout className="flex items-end gap-2 justify-start">
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-purple-500">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div className="rounded-2xl rounded-bl-none bg-gray-700 px-4 py-2 text-gray-200">
              <div className="flex items-center gap-1">
                <span className="h-2 w-2 animate-pulse rounded-full bg-gray-400 delay-0"></span>
                <span className="h-2 w-2 animate-pulse rounded-full bg-gray-400 delay-150"></span>
                <span className="h-2 w-2 animate-pulse rounded-full bg-gray-400 delay-300"></span>
              </div>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            handleSend()
          }}
          className="flex items-center gap-2"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your finances..."
            className="flex-1 bg-gray-800 text-white"
            disabled={isLoading}
          />
          <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
            <Send />
          </Button>
        </form>
      </div>
    </motion.div>
  )
}
