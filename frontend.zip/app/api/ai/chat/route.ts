import { NextResponse } from "next/server"

const financialData = {
  netWorth: 127842,
  spending: {
    total: 4200,
    categories: {
      "Food & Dining": 850,
      Shopping: 600,
      Housing: 1500,
      Entertainment: 350,
    },
  },
  bills: 3,
}

export async function POST(request: Request) {
  const { message } = await request.json()
  const lowerCaseMessage = message.toLowerCase()

  await new Promise((resolve) => setTimeout(resolve, 1000))

  let reply = "I'm not sure how to answer that. I can tell you about your net worth, spending, or upcoming bills."

  if (lowerCaseMessage.includes("net worth")) {
    reply = `Your current net worth is $${financialData.netWorth.toLocaleString()}. This is calculated by subtracting your liabilities from your assets.`
  } else if (lowerCaseMessage.includes("spending")) {
    reply = `This month, you've spent $${financialData.spending.total.toLocaleString()}. Your top category is Housing at $1,500.`
  } else if (lowerCaseMessage.includes("bills")) {
    reply = `You have ${financialData.bills} upcoming bills. You can see the details on the 'Bills' screen.`
  }

  return NextResponse.json({ reply })
}
